Ext.define('Ext.ux.auth.model.Session', {
    fields: ['username', 'created_at', 'expires_at'],
    
    validate: function() {
        
    },
    
    destroy: function() {
        
    }
});