To run Compass,
open the terminal to this folder,

type
$> compass watch resources/scss
